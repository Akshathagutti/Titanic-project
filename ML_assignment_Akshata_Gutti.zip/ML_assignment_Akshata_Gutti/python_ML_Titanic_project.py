# -*- coding: utf-8 -*-
"""
Created on Tue Jan 22 11:06:18 2021

@author: Akshata gutti
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import BaggingClassifier, RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn import svm
dataset = pd.read_csv(r"F:\PYTHON_ML\EDA1-master\titanic_train.csv")
#print(dataset.head())
print(dataset.columns)
"""============Exploratory Data Analysis============= """
#print(dataset.isnull())
#print(dataset.info())
sns.heatmap(dataset.isnull(),yticklabels=False,cbar=False,cmap='viridis')
#sns.set_style('whitegrid')
sns.countplot(x='Survived',data=dataset)
sns.countplot(x='Survived',hue='Sex',data=dataset,palette='RdBu_r')
sns.countplot(x='Survived',hue='Pclass',data=dataset,palette='rainbow')

sns.distplot(dataset['Age'].dropna(),kde=True,color='darkred',bins=40)

dataset['Age'].hist(bins=30,color='darkred',alpha=0.3)
sns.countplot(x='SibSp',data=dataset)

""" There is a relation between  age and passenger class so I will update the null value of
    age with average age."""
sns.boxplot(x='Pclass',y='Age',data=dataset,palette='winter')

# replacing age clounm with average of age
def impute_age(cols):
    Age = cols[0]
    Pclass = cols[1]
    
    if pd.isnull(Age):

        if Pclass == 1:
            return 37

        elif Pclass == 2:
            return 29

        else:
            return 24
    else:
        return Age
dataset['Age'] = dataset[['Age','Pclass']].apply(impute_age,axis=1)
dataset =dataset.drop(['Cabin'], axis = 1)
dataset =dataset.dropna()
sns.heatmap(dataset.isnull(),yticklabels=False,cbar=False,cmap='viridis')
dataset.info()

"""========Converting Categorical Features======="""
sex = pd.get_dummies(dataset['Sex'],drop_first=True)
embark = pd.get_dummies(dataset['Embarked'],drop_first=True)
dataset.drop(['Sex','Embarked','Name','Ticket'],axis=1,inplace=True)
dataset = pd.concat([dataset,sex,embark],axis=1)
dataset.head()


"""=====Logistic Regression model===="""
X= dataset.drop('Survived',axis=1)
Y = dataset['Survived']
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.30, random_state=101)
from sklearn.linear_model import LogisticRegression
logisticmodel = LogisticRegression()
logisticmodel.fit(X_train,y_train)
predictions = logisticmodel.predict(X_test)
from sklearn.metrics import confusion_matrix
accuracy=confusion_matrix(y_test,predictions)
accuracy

accuracy=accuracy_score(y_test,predictions)
accuracy

#logisticmodel = 0.797752808988764

""" ======AdaBoostClassifier ===="""
adaboost = AdaBoostClassifier()
adaboost.fit(X_train, y_train)
predictions = adaboost.predict(X_test)
accuracy_ad=confusion_matrix(y_test,predictions)
accuracy_ad
accuracy_ad=accuracy_score(y_test,predictions)
accuracy_ad
# accuracy adaboost = 0.7865168539325843
"""====RandomForestClassifier====="""
random_forest = RandomForestClassifier(n_estimators=100)
random_forest.fit(X_train, y_train)
random_forest_predictions = random_forest.predict(X_test)
accuracy_random_forest=confusion_matrix(y_test,random_forest_predictions)
accuracy_random_forest
accuracy_random_forest=accuracy_score(y_test,random_forest_predictions)
accuracy_random_forest
# accuracy RandomForestClassifier = 0.8426966292134831
